package org.recycleview;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;

public class WordListAdapter extends RecyclerView.Adapter<WordListAdapter.WordViewHolder>{

    @NonNull
    @org.jetbrains.annotations.NotNull
    @Override
    public WordListAdapter.WordViewHolder onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup viewGroup, int i) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull @org.jetbrains.annotations.NotNull WordListAdapter.WordViewHolder wordViewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
    class WordViewHolder extends RecyclerView.ViewHolder {
        public final TextView wordItemView;
        final WordListAdapter mAdapter;

        public WordViewHolder(@NonNull @NotNull View itemView, TextView wordItemView, WordListAdapter mAdapter) {
            super(itemView);
            this.wordItemView = wordItemView;
            this.mAdapter = mAdapter;
        }

        public WordViewHolder(View itemView, WordListAdapter adapter) {
            super(itemView);
            wordItemView = itemView.findViewById(R.id.word);
            this.mAdapter = adapter;
        }
    }
}
