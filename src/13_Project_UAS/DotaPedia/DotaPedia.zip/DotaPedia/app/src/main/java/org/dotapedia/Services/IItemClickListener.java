package org.dotapedia.Services;

import android.view.View;

public interface IItemClickListener {

    void onClick(View view, int position);
}
