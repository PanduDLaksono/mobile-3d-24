package org.dotapedia.Utils;

import org.dotapedia.Models.Hero;

import java.util.ArrayList;
import java.util.List;

public class Common {
    public static List<Hero> commonHeroList = new ArrayList<>();
    public static final String KEY_ENABLE_HOME = "enable_home";
}
